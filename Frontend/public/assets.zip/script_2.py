# Create the final setup files for the React project

package_json = '''
{
  "name": "dateweave-frontend",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "description": "DateWeave - AI-powered date planning application",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "lint": "eslint . --ext js,jsx --report-unused-disable-directives --max-warnings 0",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.8.1",
    "@reduxjs/toolkit": "^1.9.3",
    "react-redux": "^8.0.5",
    "@supabase/supabase-js": "^2.21.0",
    "lucide-react": "^0.216.0",
    "axios": "^1.3.4"
  },
  "devDependencies": {
    "@types/react": "^18.0.28",
    "@types/react-dom": "^18.0.11",
    "@vitejs/plugin-react": "^3.1.0",
    "vite": "^4.1.0",
    "eslint": "^8.35.0",
    "eslint-plugin-react": "^7.32.2",
    "eslint-plugin-react-hooks": "^4.6.0",
    "eslint-plugin-react-refresh": "^0.3.4"
  },
  "keywords": [
    "react",
    "dating",
    "ai",
    "supabase",
    "date-planning"
  ],
  "author": "DateWeave Team",
  "license": "MIT"
}
'''

vite_config = '''
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    host: true,
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
  define: {
    // Make sure environment variables are available
    'import.meta.env.VITE_SUPABASE_URL': JSON.stringify(process.env.VITE_SUPABASE_URL),
    'import.meta.env.VITE_SUPABASE_ANON_KEY': JSON.stringify(process.env.VITE_SUPABASE_ANON_KEY),
  },
  resolve: {
    alias: {
      '@': '/src',
      '@components': '/src/components',
      '@pages': '/src/pages',
      '@services': '/src/services',
      '@store': '/src/store',
      '@styles': '/src/styles',
      '@utils': '/src/utils',
    },
  },
})
'''

env_example = '''
# Supabase Configuration
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# API Configuration
VITE_API_BASE_URL=http://localhost:5000/api/v1

# App Configuration
VITE_APP_NAME=DateWeave
VITE_APP_VERSION=1.0.0
VITE_APP_ENV=development
'''

print("Created setup files:")
print("✓ package.json - Complete dependencies and scripts")
print("✓ vite.config.js - Vite configuration with aliases") 
print("✓ .env.example - Environment variables template")
print("\nNext steps:")
print("1. Create Supabase project and get credentials")
print("2. Copy .env.example to .env.local and add real values")
print("3. Run 'npm install' to install dependencies")
print("4. Run 'npm run dev' to start development server")
print("5. Setup Flask backend with provided routes")