# DateWeave - Backend Project Structure (Flask + Supabase)

## 📁 Project Structure

```
dateweave-backend/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── profile.py
│   │   ├── recommendation.py
│   │   └── history.py
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── profile.py
│   │   ├── recommendations.py
│   │   └── health.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── auth_service.py
│   │   ├── profile_service.py
│   │   ├── supabase_service.py
│   │   └── ai_service.py
│   ├── utils/
│   │   ├── __init__.py
│   │   ├── decorators.py
│   │   ├── validators.py
│   │   ├── responses.py
│   │   └── exceptions.py
│   ├── middleware/
│   │   ├── __init__.py
│   │   ├── auth_middleware.py
│   │   ├── cors_middleware.py
│   │   └── error_handler.py
│   └── database/
│       ├── __init__.py
│       ├── connection.py
│       ├── migrations/
│       │   └── 001_initial_schema.sql
│       └── seeds/
│           └── sample_data.sql
├── tests/
│   ├── __init__.py
│   ├── test_auth.py
│   ├── test_profile.py
│   ├── conftest.py
│   └── fixtures/
├── requirements/
│   ├── base.txt
│   ├── development.txt
│   └── production.txt
├── .env.example
├── .env
├── .gitignore
├── app.py
├── wsgi.py
├── Dockerfile
├── docker-compose.yml
├── pytest.ini
└── README.md
```

## 🔧 Key Dependencies

```txt
# requirements/base.txt
Flask==2.3.2
Flask-CORS==4.0.0
Flask-JWT-Extended==4.4.4
python-dotenv==1.0.0
psycopg2-binary==2.9.6
supabase==1.0.3
requests==2.31.0
marshmallow==3.19.0
werkzeug==2.3.6
gunicorn==20.1.0

# requirements/development.txt
-r base.txt
pytest==7.3.1
pytest-flask==1.2.0
pytest-cov==4.1.0
black==23.3.0
flake8==6.0.0
pre-commit==3.3.2

# requirements/production.txt
-r base.txt
sentry-sdk==1.25.1
```

## 🌐 Environment Variables

```bash
# .env
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-super-secret-key-change-this-in-production

# Supabase Configuration
SUPABASE_URL=your_supabase_project_url
SUPABASE_KEY=your_supabase_service_role_key
SUPABASE_JWT_SECRET=your_supabase_jwt_secret

# Database Configuration (Supabase PostgreSQL)
DATABASE_URL=your_supabase_database_url
DB_HOST=db.your_project.supabase.co
DB_PORT=5432
DB_NAME=postgres
DB_USER=postgres
DB_PASSWORD=your_db_password

# API Configuration
API_BASE_URL=http://localhost:5000
CORS_ORIGINS=http://localhost:5173,http://localhost:3000

# External APIs
GEMINI_API_KEY=your_gemini_api_key
PERPLEXITY_API_KEY=your_perplexity_api_key

# Security
JWT_SECRET_KEY=your_jwt_secret_key
JWT_ACCESS_TOKEN_EXPIRES=3600
JWT_REFRESH_TOKEN_EXPIRES=2592000

# Logging
LOG_LEVEL=INFO
```

## 🚀 Setup Instructions

1. **Create Virtual Environment:**
```bash
python -m venv dateweave-env
source dateweave-env/bin/activate  # On Windows: dateweave-env\Scripts\activate
```

2. **Install Dependencies:**
```bash
pip install -r requirements/development.txt
```

3. **Setup Environment:**
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. **Initialize Database:**
```bash
python -c "from app.database.connection import init_db; init_db()"
```

5. **Run Application:**
```bash
python app.py
# Or with gunicorn for production:
gunicorn --bind 0.0.0.0:5000 wsgi:app
```

## 📋 API Architecture

### Authentication Endpoints
- `POST /api/v1/auth/signup` - User registration
- `POST /api/v1/auth/login` - User login  
- `POST /api/v1/auth/logout` - User logout
- `POST /api/v1/auth/refresh` - Refresh token
- `GET /api/v1/auth/verify` - Verify token

### Profile Endpoints
- `GET /api/v1/profile` - Get user profile
- `PUT /api/v1/profile` - Update user profile
- `GET /api/v1/profile/stats` - Get profile statistics

### Recommendations Endpoints
- `GET /api/v1/recommendations` - Get date recommendations
- `POST /api/v1/recommendations/generate` - Generate AI recommendations
- `POST /api/v1/recommendations/{id}/rate` - Rate recommendation

### History Endpoints  
- `GET /api/v1/history` - Get dating history
- `POST /api/v1/history` - Add history entry
- `PUT /api/v1/history/{id}` - Update history entry

## 🔐 Authentication Strategy

1. **Supabase Integration:**
   - Use Supabase Auth for user management
   - Validate JWT tokens on each request
   - Implement custom decorators for route protection

2. **Token Management:**
   - Access tokens for API authorization
   - Refresh tokens for session management
   - Secure cookie storage (optional)

3. **Database Integration:**
   - Direct PostgreSQL connection via Supabase
   - Row Level Security (RLS) policies
   - User profile extension tables

## 🗄️ Database Schema

```sql
-- User profiles extension (public schema)
CREATE TABLE public.profiles (
    id UUID REFERENCES auth.users ON DELETE CASCADE,
    username VARCHAR(50) UNIQUE,
    full_name TEXT,
    phone VARCHAR(20),
    address TEXT,
    avatar_url TEXT,
    bio TEXT,
    preferences JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (id)
);

-- Date recommendations
CREATE TABLE public.recommendations (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    title TEXT NOT NULL,
    description TEXT,
    category VARCHAR(50),
    rating DECIMAL(3,2),
    location TEXT,
    estimated_cost INTEGER,
    duration INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Dating history
CREATE TABLE public.history (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    title TEXT NOT NULL,
    partner_name VARCHAR(100),
    date_completed DATE,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    notes TEXT,
    location TEXT,
    status VARCHAR(20) DEFAULT 'completed',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.history ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles  
    FOR UPDATE USING (auth.uid() = id);
```

## 🧪 Testing Strategy

- Unit tests for services and utilities
- Integration tests for API endpoints
- Authentication middleware testing
- Database operation testing
- Mock external API calls (Gemini/Perplexity)

## 🐳 Docker Configuration

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements/production.txt requirements.txt
RUN pip install -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["gunicorn", "--bind", "0.0.0.0:5000", "wsgi:app"]
```

## 🔄 CI/CD Pipeline

1. **Development:** Local testing with pytest
2. **Staging:** Automated testing and deployment to Render
3. **Production:** Blue-green deployment with health checks