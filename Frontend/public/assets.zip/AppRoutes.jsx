import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import Login from '../pages/auth/Login'
import Signup from '../pages/auth/Signup'
import Profile from '../pages/Profile'
import Dashboard from '../pages/Dashboard'
import Calendar from '../pages/Calendar'
import Room from '../pages/Room'
import Settings from '../pages/Settings'
import ProtectedRoute from './ProtectedRoute'

const AppRoutes = () => {
  const { isLoggedIn } = useSelector((state) => state.auth)

  return (
    <Routes>
      {/* Public Routes */}
      <Route 
        path="/auth/login" 
        element={isLoggedIn ? <Navigate to="/profile" replace /> : <Login />} 
      />
      <Route 
        path="/auth/signup" 
        element={isLoggedIn ? <Navigate to="/profile" replace /> : <Signup />} 
      />

      {/* Protected Routes */}
      <Route path="/profile" element={
        <ProtectedRoute>
          <Profile />
        </ProtectedRoute>
      } />
      
      <Route path="/dashboard" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />
      
      <Route path="/add" element={
        <ProtectedRoute>
          <Dashboard />
        </ProtectedRoute>
      } />
      
      <Route path="/calendar" element={
        <ProtectedRoute>
          <Calendar />
        </ProtectedRoute>
      } />
      
      <Route path="/room" element={
        <ProtectedRoute>
          <Room />
        </ProtectedRoute>
      } />
      
      <Route path="/settings" element={
        <ProtectedRoute>
          <Settings />
        </ProtectedRoute>
      } />

      {/* Default redirects */}
      <Route 
        path="/" 
        element={
          <Navigate to={isLoggedIn ? "/profile" : "/auth/login"} replace />
        } 
      />
      
      {/* Catch all route */}
      <Route 
        path="*" 
        element={
          <Navigate to={isLoggedIn ? "/profile" : "/auth/login"} replace />
        } 
      />
    </Routes>
  )
}

export default AppRoutes