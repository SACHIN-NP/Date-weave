# DateWeave - Frontend Project Structure (React + Vite)

## 📁 Project Structure

```
dateweave-frontend/
├── public/
│   ├── assets/
│   │   ├── images/
│   │   │   ├── logo.jpg
│   │   │   └── profile.jpg
│   │   └── icons/
│   ├── index.html
│   └── favicon.ico
├── src/
│   ├── assets/
│   │   ├── images/
│   │   └── icons/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Button/
│   │   │   │   ├── Button.jsx
│   │   │   │   └── index.js
│   │   │   ├── Input/
│   │   │   │   ├── Input.jsx
│   │   │   │   └── index.js
│   │   │   ├── Card/
│   │   │   │   ├── Card.jsx
│   │   │   │   └── index.js
│   │   │   └── Layout/
│   │   │       ├── Layout.jsx
│   │   │       ├── Sidebar/
│   │   │       │   ├── Sidebar.jsx
│   │   │       │   └── index.js
│   │   │       └── index.js
│   │   └── features/
│   │       ├── auth/
│   │       │   ├── LoginForm/
│   │       │   │   ├── LoginForm.jsx
│   │       │   │   └── index.js
│   │       │   └── SignupForm/
│   │       │       ├── SignupForm.jsx
│   │       │       └── index.js
│   │       └── profile/
│   │           ├── ProfileHeader/
│   │           │   ├── ProfileHeader.jsx
│   │           │   └── index.js
│   │           ├── ProfileStats/
│   │           │   ├── ProfileStats.jsx
│   │           │   └── index.js
│   │           ├── Recommendations/
│   │           │   ├── Recommendations.jsx
│   │           │   └── index.js
│   │           └── History/
│   │               ├── History.jsx
│   │               └── index.js
│   ├── pages/
│   │   ├── auth/
│   │   │   ├── Login.jsx
│   │   │   ├── Signup.jsx
│   │   │   └── index.js
│   │   ├── Profile.jsx
│   │   ├── Dashboard.jsx
│   │   ├── Calendar.jsx
│   │   ├── Room.jsx
│   │   ├── Settings.jsx
│   │   └── index.js
│   ├── hooks/
│   │   ├── useAuth.js
│   │   ├── useProfile.js
│   │   └── useApi.js
│   ├── services/
│   │   ├── supabase/
│   │   │   ├── client.js
│   │   │   ├── auth.js
│   │   │   └── database.js
│   │   └── api/
│   │       ├── auth.js
│   │       ├── profile.js
│   │       └── recommendations.js
│   ├── store/
│   │   ├── slices/
│   │   │   ├── authSlice.js
│   │   │   ├── profileSlice.js
│   │   │   └── themeSlice.js
│   │   ├── store.js
│   │   └── index.js
│   ├── styles/
│   │   ├── globals.css
│   │   ├── variables.css
│   │   ├── components/
│   │   │   ├── buttons.css
│   │   │   ├── forms.css
│   │   │   └── cards.css
│   │   └── themes/
│   │       ├── light.css
│   │       └── dark.css
│   ├── utils/
│   │   ├── constants.js
│   │   ├── formatters.js
│   │   └── validators.js
│   ├── contexts/
│   │   ├── AuthContext.jsx
│   │   └── ThemeContext.jsx
│   ├── routes/
│   │   ├── AppRoutes.jsx
│   │   ├── ProtectedRoute.jsx
│   │   └── index.js
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── .env.example
├── .env.local
├── .gitignore
├── package.json
├── vite.config.js
├── tailwind.config.js (optional)
└── README.md
```

## 🔧 Key Dependencies

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.8.1",
    "@reduxjs/toolkit": "^1.9.3",
    "react-redux": "^8.0.5",
    "@supabase/supabase-js": "^2.21.0",
    "axios": "^1.3.4",
    "lucide-react": "^0.216.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^3.1.0",
    "vite": "^4.1.0",
    "eslint": "^8.35.0",
    "@types/react": "^18.0.28",
    "@types/react-dom": "^18.0.11"
  }
}
```

## 🌐 Environment Variables

```bash
# .env.local
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_API_BASE_URL=http://localhost:5000/api/v1
VITE_APP_NAME=DateWeave
VITE_APP_VERSION=1.0.0
```

## 🚀 Setup Instructions

1. **Create Vite Project:**
```bash
npm create vite@latest dateweave-frontend --template react
cd dateweave-frontend
```

2. **Install Dependencies:**
```bash
npm install @reduxjs/toolkit react-redux @supabase/supabase-js react-router-dom axios lucide-react
```

3. **Setup Environment:**
```bash
cp .env.example .env.local
# Edit .env.local with your Supabase credentials
```

4. **Start Development:**
```bash
npm run dev
```

## 📋 Component Architecture

- **Common Components**: Reusable UI elements following the design system
- **Feature Components**: Domain-specific components (auth, profile, etc.)
- **Pages**: Route-level components that compose features
- **Hooks**: Custom React hooks for business logic
- **Services**: API and external service integrations
- **Store**: Redux Toolkit state management
- **Styles**: Maintain existing CSS design system