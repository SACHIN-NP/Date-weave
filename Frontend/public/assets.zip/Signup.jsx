import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { Eye, EyeOff, Mail, Lock, User, MapPin, Heart } from 'lucide-react'
import { supabase } from '../../services/supabase/client'
import { setLoading, setError } from '../../store/slices/authSlice'

const Signup = () => {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { isLoggedIn, loading, error } = useSelector((state) => state.auth)
  
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    address: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [hovered, setHovered] = useState(false)
  const [validationErrors, setValidationErrors] = useState({})
  const [successMessage, setSuccessMessage] = useState('')

  // Redirect if already logged in
  useEffect(() => {
    if (isLoggedIn) {
      navigate('/profile')
    }
  }, [isLoggedIn, navigate])

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    
    // Clear validation error for this field
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }))
    }
  }

  const validateForm = () => {
    const errors = {}
    
    if (!formData.username.trim()) {
      errors.username = 'Username is required'
    } else if (formData.username.length < 3) {
      errors.username = 'Username must be at least 3 characters'
    } else if (!/^[a-zA-Z0-9_]+$/.test(formData.username)) {
      errors.username = 'Username can only contain letters, numbers, and underscores'
    }
    
    if (!formData.email) {
      errors.email = 'Email is required'
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Email is invalid'
    }
    
    if (!formData.password) {
      errors.password = 'Password is required'
    } else if (formData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters'
    }
    
    if (!formData.confirmPassword) {
      errors.confirmPassword = 'Please confirm your password'
    } else if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = 'Passwords do not match'
    }
    
    if (!formData.address.trim()) {
      errors.address = 'Address is required'
    }
    
    setValidationErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    dispatch(setLoading(true))
    dispatch(setError(null))
    setSuccessMessage('')

    try {
      // Step 1: Create user account with Supabase Auth
      const { data, error: signUpError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            username: formData.username,
            full_name: formData.username, // You can modify this later
            address: formData.address
          }
        }
      })

      if (signUpError) throw signUpError

      if (data?.user && !data?.session) {
        // Email confirmation required
        setSuccessMessage(
          'Registration successful! Please check your email to confirm your account before signing in.'
        )
        
        // Clear form
        setFormData({
          username: '',
          email: '',
          password: '',
          confirmPassword: '',
          address: ''
        })
        
        // Redirect to login page after 3 seconds
        setTimeout(() => {
          navigate('/auth/login')
        }, 3000)
      } else if (data?.session) {
        // User is immediately signed in
        setSuccessMessage('Registration successful! Redirecting to your profile...')
        setTimeout(() => {
          navigate('/profile')
        }, 2000)
      }
      
    } catch (error) {
      console.error('Signup error:', error)
      dispatch(setError(error.message || 'Registration failed. Please try again.'))
    } finally {
      dispatch(setLoading(false))
    }
  }

  return (
    <div className="auth-container">
      <div className="auth-wrapper">
        <div className="auth-card signup-card">
          <div className="auth-header">
            <div className="logo-section">
              <div className="logo-icon">
                <Heart className="heart-icon" />
              </div>
              <h1 className="brand-title">DateWeave</h1>
            </div>
            <p className="auth-subtitle">Join us to start weaving your perfect dates</p>
          </div>

          <form onSubmit={handleSubmit} className="auth-form">
            {error && (
              <div className="error-message">
                <span className="error-icon">⚠️</span>
                {error}
              </div>
            )}

            {successMessage && (
              <div className="success-message">
                <span className="success-icon">✅</span>
                {successMessage}
              </div>
            )}

            <div className="form-group">
              <label htmlFor="username" className="form-label">
                <User className="label-icon" />
                Username
              </label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                className={`form-control ${validationErrors.username ? 'error' : ''}`}
                placeholder="Choose a username"
                required
              />
              {validationErrors.username && (
                <span className="field-error">{validationErrors.username}</span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="email" className="form-label">
                <Mail className="label-icon" />
                Email Address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className={`form-control ${validationErrors.email ? 'error' : ''}`}
                placeholder="Enter your email"
                required
              />
              {validationErrors.email && (
                <span className="field-error">{validationErrors.email}</span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="password" className="form-label">
                <Lock className="label-icon" />
                Password
              </label>
              <div className="password-input-wrapper">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className={`form-control ${validationErrors.password ? 'error' : ''}`}
                  placeholder="Create a password"
                  required
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
              {validationErrors.password && (
                <span className="field-error">{validationErrors.password}</span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="confirmPassword" className="form-label">
                <Lock className="label-icon" />
                Confirm Password
              </label>
              <div className="password-input-wrapper">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  className={`form-control ${validationErrors.confirmPassword ? 'error' : ''}`}
                  placeholder="Confirm your password"
                  required
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
                >
                  {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
              {validationErrors.confirmPassword && (
                <span className="field-error">{validationErrors.confirmPassword}</span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="address" className="form-label">
                <MapPin className="label-icon" />
                Address
              </label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                className={`form-control ${validationErrors.address ? 'error' : ''}`}
                placeholder="Enter your address"
                required
              />
              {validationErrors.address && (
                <span className="field-error">{validationErrors.address}</span>
              )}
            </div>

            <button
              type="submit"
              className={`btn btn--primary btn--full-width auth-submit-btn ${
                hovered ? 'hovered' : ''
              }`}
              disabled={loading}
              onMouseEnter={() => setHovered(true)}
              onMouseLeave={() => setHovered(false)}
            >
              {loading ? (
                <span className="loading-spinner">
                  <div className="spinner"></div>
                  Creating account...
                </span>
              ) : (
                'Sign Up'
              )}
            </button>

            <div className="auth-divider">
              <span>Or</span>
            </div>

            <div className="auth-links">
              <p className="auth-switch">
                Already have an account?{' '}
                <Link to="/auth/login" className="auth-link">
                  Sign In
                </Link>
              </p>
            </div>
          </form>
        </div>

        <div className="auth-background">
          <div className="floating-heart floating-heart-1">💖</div>
          <div className="floating-heart floating-heart-2">💝</div>
          <div className="floating-heart floating-heart-3">💕</div>
          <div className="floating-heart floating-heart-4">💗</div>
        </div>
      </div>
    </div>
  )
}

export default Signup