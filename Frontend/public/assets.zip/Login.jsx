import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { Eye, EyeOff, Mail, Lock, Heart } from 'lucide-react'
import { supabase } from '../../services/supabase/client'
import { setUser, setLoading, setError } from '../../store/slices/authSlice'

const Login = () => {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { isLoggedIn, loading, error } = useSelector((state) => state.auth)
  
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [hovered, setHovered] = useState(false)
  const [validationErrors, setValidationErrors] = useState({})

  // Redirect if already logged in
  useEffect(() => {
    if (isLoggedIn) {
      navigate('/profile')
    }
  }, [isLoggedIn, navigate])

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    
    // Clear validation error for this field
    if (validationErrors[name]) {
      setValidationErrors(prev => ({
        ...prev,
        [name]: ''
      }))
    }
  }

  const validateForm = () => {
    const errors = {}
    
    if (!formData.email) {
      errors.email = 'Email is required'
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = 'Email is invalid'
    }
    
    if (!formData.password) {
      errors.password = 'Password is required'
    } else if (formData.password.length < 6) {
      errors.password = 'Password must be at least 6 characters'
    }
    
    setValidationErrors(errors)
    return Object.keys(errors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    dispatch(setLoading(true))
    dispatch(setError(null))

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: formData.email,
        password: formData.password,
      })

      if (error) throw error

      // Redux store will be updated automatically via the auth listener in App.jsx
      navigate('/profile')
      
    } catch (error) {
      console.error('Login error:', error)
      dispatch(setError(error.message || 'Login failed. Please try again.'))
    } finally {
      dispatch(setLoading(false))
    }
  }

  return (
    <div className="auth-container">
      <div className="auth-wrapper">
        <div className="auth-card">
          <div className="auth-header">
            <div className="logo-section">
              <div className="logo-icon">
                <Heart className="heart-icon" />
              </div>
              <h1 className="brand-title">DateWeave</h1>
            </div>
            <p className="auth-subtitle">Welcome back! Sign in to continue your journey</p>
          </div>

          <form onSubmit={handleSubmit} className="auth-form">
            {error && (
              <div className="error-message">
                <span className="error-icon">⚠️</span>
                {error}
              </div>
            )}

            <div className="form-group">
              <label htmlFor="email" className="form-label">
                <Mail className="label-icon" />
                Email Address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className={`form-control ${validationErrors.email ? 'error' : ''}`}
                placeholder="Enter your email"
                required
              />
              {validationErrors.email && (
                <span className="field-error">{validationErrors.email}</span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="password" className="form-label">
                <Lock className="label-icon" />
                Password
              </label>
              <div className="password-input-wrapper">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className={`form-control ${validationErrors.password ? 'error' : ''}`}
                  placeholder="Enter your password"
                  required
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
              {validationErrors.password && (
                <span className="field-error">{validationErrors.password}</span>
              )}
            </div>

            <button
              type="submit"
              className={`btn btn--primary btn--full-width auth-submit-btn ${
                hovered ? 'hovered' : ''
              }`}
              disabled={loading}
              onMouseEnter={() => setHovered(true)}
              onMouseLeave={() => setHovered(false)}
            >
              {loading ? (
                <span className="loading-spinner">
                  <div className="spinner"></div>
                  Signing in...
                </span>
              ) : (
                'Sign In'
              )}
            </button>

            <div className="auth-divider">
              <span>Or</span>
            </div>

            <div className="auth-links">
              <p className="auth-switch">
                Don't have an account?{' '}
                <Link to="/auth/signup" className="auth-link">
                  Sign Up
                </Link>
              </p>
            </div>
          </form>
        </div>

        <div className="auth-background">
          <div className="floating-heart floating-heart-1">💖</div>
          <div className="floating-heart floating-heart-2">💝</div>
          <div className="floating-heart floating-heart-3">💕</div>
        </div>
      </div>
    </div>
  )
}

export default Login