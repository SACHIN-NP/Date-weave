# Flask Backend - Authentication Routes
from flask import Blueprint, request, jsonify, current_app
from functools import wraps
import jwt
import os
from supabase import create_client, Client
import psycopg2
from psycopg2.extras import RealDictCursor

auth_bp = Blueprint('auth', __name__)

# Initialize Supabase client
supabase_url = os.getenv('SUPABASE_URL')
supabase_service_key = os.getenv('SUPABASE_SERVICE_KEY')
supabase: Client = create_client(supabase_url, supabase_service_key)

# JWT Secret from Supabase
JWT_SECRET = os.getenv('SUPABASE_JWT_SECRET')

def verify_jwt_token(token):
    """Verify Supabase JWT token"""
    try:
        # Remove 'Bearer ' prefix if present
        if token.startswith('Bearer '):
            token = token[7:]
        
        # Decode JWT token
        decoded_token = jwt.decode(
            token, 
            JWT_SECRET, 
            algorithms=['HS256'],
            audience='authenticated'
        )
        
        return decoded_token
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def token_required(f):
    """Decorator to require valid JWT token"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({
                'error': 'Token is missing',
                'message': 'Authorization header is required'
            }), 401
        
        token_data = verify_jwt_token(token)
        if not token_data:
            return jsonify({
                'error': 'Invalid token',
                'message': 'Token is expired or invalid'
            }), 401
        
        # Add user ID to request context
        request.current_user_id = token_data.get('sub')
        return f(*args, **kwargs)
    
    return decorated

@auth_bp.route('/verify', methods=['POST'])
def verify_token():
    """Verify if the provided token is valid"""
    try:
        token = request.headers.get('Authorization')
        
        if not token:
            return jsonify({
                'valid': False,
                'message': 'No token provided'
            }), 400
        
        token_data = verify_jwt_token(token)
        
        if token_data:
            return jsonify({
                'valid': True,
                'user_id': token_data.get('sub'),
                'email': token_data.get('email'),
                'exp': token_data.get('exp')
            }), 200
        else:
            return jsonify({
                'valid': False,
                'message': 'Invalid or expired token'
            }), 401
            
    except Exception as e:
        return jsonify({
            'valid': False,
            'message': 'Token verification failed',
            'error': str(e)
        }), 500

@auth_bp.route('/user', methods=['GET'])
@token_required
def get_current_user():
    """Get current user information"""
    try:
        user_id = request.current_user_id
        
        # Get user from Supabase auth
        response = supabase.auth.admin.get_user_by_id(user_id)
        
        if response.user:
            # Get additional profile data
            profile_response = supabase.table('profiles').select('*').eq('id', user_id).execute()
            
            profile_data = profile_response.data[0] if profile_response.data else {}
            
            return jsonify({
                'user': {
                    'id': response.user.id,
                    'email': response.user.email,
                    'phone': response.user.phone,
                    'user_metadata': response.user.user_metadata,
                    'profile': profile_data
                }
            }), 200
        else:
            return jsonify({
                'error': 'User not found'
            }), 404
            
    except Exception as e:
        return jsonify({
            'error': 'Failed to get user',
            'message': str(e)
        }), 500

@auth_bp.route('/profile', methods=['GET'])
@token_required
def get_user_profile():
    """Get user profile information"""
    try:
        user_id = request.current_user_id
        
        # Get profile data from database
        response = supabase.table('profiles').select('*').eq('id', user_id).execute()
        
        if response.data:
            profile = response.data[0]
            
            # Get additional statistics
            recommendations_count = supabase.table('recommendations').select('id', count='exact').eq('user_id', user_id).execute()
            history_count = supabase.table('history').select('id', count='exact').eq('user_id', user_id).execute()
            completed_dates = supabase.table('history').select('id', count='exact').eq('user_id', user_id).eq('status', 'completed').execute()
            
            profile['stats'] = {
                'total_plans': recommendations_count.count or 0,
                'succeeded_plans': completed_dates.count or 0,
                'fan_count': 0  # Placeholder for future feature
            }
            
            return jsonify({
                'profile': profile
            }), 200
        else:
            return jsonify({
                'error': 'Profile not found'
            }), 404
            
    except Exception as e:
        return jsonify({
            'error': 'Failed to get profile',
            'message': str(e)
        }), 500

@auth_bp.route('/profile', methods=['PUT'])
@token_required
def update_user_profile():
    """Update user profile information"""
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        # Validate input data
        allowed_fields = ['username', 'full_name', 'phone', 'address', 'bio', 'preferences']
        update_data = {k: v for k, v in data.items() if k in allowed_fields}
        
        if not update_data:
            return jsonify({
                'error': 'No valid fields to update'
            }), 400
        
        # Add timestamp
        update_data['updated_at'] = 'now()'
        
        # Update profile in database
        response = supabase.table('profiles').update(update_data).eq('id', user_id).execute()
        
        if response.data:
            return jsonify({
                'message': 'Profile updated successfully',
                'profile': response.data[0]
            }), 200
        else:
            # If profile doesn't exist, create it
            create_data = {**update_data, 'id': user_id}
            create_response = supabase.table('profiles').insert(create_data).execute()
            
            return jsonify({
                'message': 'Profile created successfully',
                'profile': create_response.data[0]
            }), 201
            
    except Exception as e:
        return jsonify({
            'error': 'Failed to update profile',
            'message': str(e)
        }), 500

@auth_bp.route('/recommendations', methods=['GET'])
@token_required
def get_recommendations():
    """Get user's date recommendations"""
    try:
        user_id = request.current_user_id
        
        response = supabase.table('recommendations').select('*').eq('user_id', user_id).order('created_at', desc=True).execute()
        
        return jsonify({
            'recommendations': response.data
        }), 200
        
    except Exception as e:
        return jsonify({
            'error': 'Failed to get recommendations',
            'message': str(e)
        }), 500

@auth_bp.route('/history', methods=['GET'])
@token_required
def get_dating_history():
    """Get user's dating history"""
    try:
        user_id = request.current_user_id
        
        response = supabase.table('history').select('*').eq('user_id', user_id).order('date_completed', desc=True).execute()
        
        return jsonify({
            'history': response.data
        }), 200
        
    except Exception as e:
        return jsonify({
            'error': 'Failed to get history',
            'message': str(e)
        }), 500

@auth_bp.route('/history', methods=['POST'])
@token_required
def add_dating_history():
    """Add new dating history entry"""
    try:
        user_id = request.current_user_id
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'partner_name', 'date_completed', 'rating']
        if not all(field in data for field in required_fields):
            return jsonify({
                'error': 'Missing required fields',
                'required': required_fields
            }), 400
        
        # Validate rating
        if not (1 <= data.get('rating', 0) <= 5):
            return jsonify({
                'error': 'Rating must be between 1 and 5'
            }), 400
        
        # Prepare data for insertion
        history_data = {
            'user_id': user_id,
            'title': data['title'],
            'partner_name': data['partner_name'],
            'date_completed': data['date_completed'],
            'rating': data['rating'],
            'notes': data.get('notes', ''),
            'location': data.get('location', ''),
            'status': data.get('status', 'completed')
        }
        
        # Insert into database
        response = supabase.table('history').insert(history_data).execute()
        
        return jsonify({
            'message': 'Dating history added successfully',
            'history': response.data[0]
        }), 201
        
    except Exception as e:
        return jsonify({
            'error': 'Failed to add history',
            'message': str(e)
        }), 500