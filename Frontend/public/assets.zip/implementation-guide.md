# DateWeave - Implementation Guide & Requirements

## 🎯 Project Overview

DateWeave is a comprehensive date planning application that helps users discover, plan, and track their dating experiences through AI-powered recommendations and personalized insights.

## 🔧 Tech Stack & Requirements

### Frontend (React + Vite)
- **React 18+** with hooks and functional components
- **Redux Toolkit** for state management
- **React Router v6** for routing
- **Supabase JS** for authentication and database
- **Lucide React** for consistent icons
- **CSS Variables** design system (existing)

### Backend (Flask + Supabase)
- **Flask 2.3+** with RESTful API architecture
- **Supabase** for PostgreSQL database and authentication
- **Flask-JWT-Extended** for token management
- **Psycopg2** for direct database operations
- **Marshmallow** for data validation
- **Gunicorn** for production deployment

### Infrastructure
- **Supabase** - Database, Authentication, Storage
- **Render** - Application deployment
- **GitHub Actions** - CI/CD pipeline

## 📋 Step-by-Step Implementation

### Phase 1: Setup & Authentication (Current Focus)

#### 1.1 Frontend Setup
```bash
# Create Vite project
npm create vite@latest dateweave-frontend --template react
cd dateweave-frontend

# Install dependencies
npm install @reduxjs/toolkit react-redux @supabase/supabase-js react-router-dom lucide-react

# Setup environment variables
cp .env.example .env.local
# Add your Supabase credentials
```

#### 1.2 Backend Setup
```bash
# Create virtual environment
python -m venv dateweave-env
source dateweave-env/bin/activate

# Install dependencies
pip install flask flask-cors flask-jwt-extended python-dotenv psycopg2-binary supabase

# Setup environment variables
cp .env.example .env
# Add your Supabase credentials
```

#### 1.3 Supabase Configuration
1. Create new Supabase project at https://app.supabase.com
2. Note down:
   - Project URL
   - Anon (public) key
   - Service role key
   - JWT Secret
3. Configure authentication providers (Email/Password enabled by default)
4. Set up Row Level Security policies

### Phase 2: Database Schema

#### 2.1 User Profiles Extension
```sql
-- Create profiles table in public schema
CREATE TABLE public.profiles (
    id UUID REFERENCES auth.users ON DELETE CASCADE,
    username VARCHAR(50) UNIQUE,
    full_name TEXT,
    phone VARCHAR(20),
    address TEXT,
    avatar_url TEXT,
    bio TEXT,
    preferences JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (id)
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles  
    FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
    FOR INSERT WITH CHECK (auth.uid() = id);
```

#### 2.2 Application Tables
```sql
-- Date recommendations
CREATE TABLE public.recommendations (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    title TEXT NOT NULL,
    description TEXT,
    category VARCHAR(50),
    rating DECIMAL(3,2),
    location TEXT,
    estimated_cost INTEGER,
    duration INTEGER,
    ai_generated BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Dating history
CREATE TABLE public.history (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    title TEXT NOT NULL,
    partner_name VARCHAR(100),
    date_completed DATE,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    notes TEXT,
    location TEXT,
    status VARCHAR(20) DEFAULT 'completed',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS for all tables
ALTER TABLE public.recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.history ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can manage own recommendations" ON public.recommendations
    USING (auth.uid() = user_id);

CREATE POLICY "Users can manage own history" ON public.history
    USING (auth.uid() = user_id);
```

### Phase 3: Frontend Implementation

#### 3.1 Project Structure
```
src/
├── components/
│   ├── common/        # Reusable UI components
│   └── features/      # Feature-specific components
├── pages/
│   ├── auth/          # Login, Signup pages
│   └── Profile.jsx    # Main profile page
├── services/
│   └── supabase/      # Supabase client and utilities
├── store/
│   └── slices/        # Redux slices
├── routes/            # Routing configuration
└── styles/            # CSS files
```

#### 3.2 Key Components to Implement

**Authentication Components:**
- ✅ Login.jsx - Complete with Supabase integration
- ✅ Signup.jsx - Complete with validation
- ✅ ProtectedRoute.jsx - Route protection

**Profile Components:**
- ✅ Profile.jsx - Main profile page
- ProfileHeader.jsx - User info display
- ProfileStats.jsx - Statistics cards
- Recommendations.jsx - Date suggestions
- History.jsx - Dating history

**Layout Components:**
- Sidebar.jsx - Navigation sidebar
- Header.jsx - Page headers
- Layout.jsx - Main layout wrapper

#### 3.3 Redux Store Structure
```javascript
// store/slices/authSlice.js - ✅ Implemented
// store/slices/profileSlice.js
// store/slices/themeSlice.js
// store/store.js - ✅ Implemented
```

### Phase 4: Backend Implementation

#### 4.1 Flask Application Structure
```python
# app/__init__.py
from flask import Flask
from flask_cors import CORS
from app.config import Config

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    CORS(app)
    
    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.profile import profile_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/v1/auth')
    app.register_blueprint(profile_bp, url_prefix='/api/v1/profile')
    
    return app
```

#### 4.2 Authentication Service
```python
# app/services/auth_service.py
from supabase import create_client
import jwt
from functools import wraps

class AuthService:
    def __init__(self):
        self.supabase = create_client(
            supabase_url=os.getenv('SUPABASE_URL'),
            supabase_key=os.getenv('SUPABASE_SERVICE_KEY')
        )
    
    def verify_token(self, token):
        # Verify JWT token with Supabase
        pass
    
    def get_user_profile(self, user_id):
        # Fetch user profile from database
        pass
```

#### 4.3 API Endpoints to Implement

**Authentication Endpoints:**
```
POST /api/v1/auth/verify-token    # Verify Supabase JWT
GET  /api/v1/auth/user           # Get current user info
POST /api/v1/auth/refresh        # Refresh session
```

**Profile Endpoints:**
```
GET  /api/v1/profile             # Get user profile
PUT  /api/v1/profile             # Update user profile
GET  /api/v1/profile/stats       # Get profile statistics
```

**Recommendations Endpoints:**
```
GET  /api/v1/recommendations     # Get user recommendations
POST /api/v1/recommendations/generate  # Generate AI recommendations
POST /api/v1/recommendations/{id}/rate # Rate recommendation
```

### Phase 5: Integration Points

#### 5.1 Supabase Authentication Flow
1. **Frontend:** User submits login/signup form
2. **Supabase:** Validates credentials, returns JWT
3. **Frontend:** Stores user session in Redux
4. **Backend:** Validates JWT on protected routes
5. **Database:** Queries use RLS with user context

#### 5.2 AI Integration (Future Phase)
```python
# app/services/ai_service.py
class AIService:
    def generate_recommendations(self, user_preferences):
        # Call Gemini API for personalized recommendations
        pass
    
    def analyze_compatibility(self, user1_prefs, user2_prefs):
        # AI-powered compatibility analysis
        pass
```

### Phase 6: Deployment

#### 6.1 Frontend Deployment (Render/Netlify)
```bash
# Build command
npm run build

# Environment variables
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
```

#### 6.2 Backend Deployment (Render)
```python
# wsgi.py
from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run()
```

```yaml
# render.yaml
services:
  - type: web
    name: dateweave-backend
    env: python
    buildCommand: "pip install -r requirements/production.txt"
    startCommand: "gunicorn wsgi:app"
    envVars:
      - key: FLASK_ENV
        value: production
      - key: SUPABASE_URL
        sync: false
      - key: SUPABASE_SERVICE_KEY
        sync: false
```

## 🔐 Security Considerations

### Authentication
- ✅ Supabase handles password hashing
- ✅ JWT tokens for session management
- ✅ Row Level Security (RLS) for data access
- 🔄 HTTPS enforcement in production
- 🔄 CORS configuration for frontend domain

### Data Protection
- Personal data encrypted at rest (Supabase default)
- Sensitive operations require re-authentication
- User data isolation through RLS policies
- Regular security audits of dependencies

## 🧪 Testing Strategy

### Frontend Testing
```bash
# Install testing dependencies
npm install -D @testing-library/react @testing-library/jest-dom vitest

# Test files
src/
├── components/
│   └── __tests__/
├── pages/
│   └── __tests__/
└── services/
    └── __tests__/
```

### Backend Testing
```python
# Install testing dependencies
pip install pytest pytest-flask

# Test structure
tests/
├── test_auth.py
├── test_profile.py
└── fixtures/
```

## 📈 Performance Optimization

### Frontend
- Code splitting with React.lazy()
- Image optimization and lazy loading
- Redux state normalization
- Bundle size monitoring

### Backend  
- Database query optimization
- Connection pooling with Supavisor
- Response caching for static data
- API rate limiting

## 🔄 Development Workflow

### 1. Current Phase - Authentication & Profile
- ✅ Setup project structure
- ✅ Implement authentication flow
- ✅ Create profile page
- 🔄 Style consistency with design system
- 🔄 Backend API integration

### 2. Next Phase - Features
- Date recommendations system
- Dating history tracking
- AI integration for personalized suggestions
- Advanced profile customization

### 3. Future Phases
- Social features (matching, messaging)
- Calendar integration
- Location-based recommendations
- Mobile app development

## 📚 Resources & Documentation

### Official Documentation
- [React Documentation](https://react.dev)
- [Supabase Docs](https://supabase.com/docs)
- [Flask Documentation](https://flask.palletsprojects.com)
- [Redux Toolkit](https://redux-toolkit.js.org)

### Design System
- Existing CSS variables and design tokens
- Component patterns from profile page
- Consistent color palette and typography
- Responsive design principles

## 🚨 Common Issues & Solutions

### Authentication Issues
- **Token expiry:** Implement refresh token logic
- **CORS errors:** Configure proper origins in Supabase
- **Session persistence:** Use Supabase session management

### Database Issues
- **RLS policies:** Test thoroughly in development
- **Connection limits:** Use connection pooling
- **Migration management:** Version control schema changes

### Deployment Issues
- **Environment variables:** Never commit secrets
- **Build failures:** Test build process locally
- **Performance:** Monitor bundle sizes and API response times