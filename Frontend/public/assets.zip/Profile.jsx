import React, { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { 
  User, 
  Calendar, 
  Home, 
  Settings, 
  Plus, 
  LogOut, 
  Star, 
  Heart,
  MapPin,
  Phone
} from 'lucide-react'
import { supabase } from '../services/supabase/client'
import { clearUser } from '../store/slices/authSlice'

const Profile = () => {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { user, isLoggedIn } = useSelector((state) => state.auth)
  
  const [activeTab, setActiveTab] = useState('profile')
  const [profileData, setProfileData] = useState({
    user: {
      name: 'Sachin Ray',
      phone: '123-456-7890',
      email: user?.email || '',
      profilePicture: '/assets/images/profile.jpg',
      stats: {
        totalPlans: 12,
        succeededPlans: 8,
        fanCount: 24
      }
    },
    recommendations: [
      {
        id: 1,
        title: 'Sunset Beach Picnic',
        description: 'Based on your love for outdoor dates',
        rating: 4.8,
        category: 'Romantic'
      },
      {
        id: 2,
        title: 'Cozy Coffee Date',
        description: 'Perfect for your casual date preferences',
        rating: 4.6,
        category: 'Casual'
      },
      {
        id: 3,
        title: 'Art Gallery Visit',
        description: 'Matches your creative interests',
        rating: 4.7,
        category: 'Cultural'
      }
    ],
    history: [
      {
        id: 1,
        date: '2025-08-20',
        title: 'Rooftop Dinner',
        partner: 'Sam',
        rating: 5,
        status: 'completed'
      },
      {
        id: 2,
        date: '2025-08-15',
        title: 'Movie Night',
        partner: 'Jordan',
        rating: 4,
        status: 'completed'
      },
      {
        id: 3,
        date: '2025-08-10',
        title: 'Hiking Adventure',
        partner: 'Casey',
        rating: 3,
        status: 'completed'
      }
    ]
  })

  // Redirect if not logged in
  useEffect(() => {
    if (!isLoggedIn) {
      navigate('/auth/login')
    }
  }, [isLoggedIn, navigate])

  // Update profile data with user info
  useEffect(() => {
    if (user) {
      setProfileData(prev => ({
        ...prev,
        user: {
          ...prev.user,
          name: user.user_metadata?.username || user.email?.split('@')[0] || 'User',
          email: user.email || '',
        }
      }))
    }
  }, [user])

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut()
      dispatch(clearUser())
      navigate('/auth/login')
    } catch (error) {
      console.error('Logout error:', error)
    }
  }

  const handleNavClick = (tabId) => {
    setActiveTab(tabId)
    
    // Navigate to different pages based on tab
    switch (tabId) {
      case 'add':
        navigate('/add')
        break
      case 'calendar':
        navigate('/calendar')
        break
      case 'room':
        navigate('/room')
        break
      case 'settings':
        navigate('/settings')
        break
      default:
        setActiveTab('profile')
    }
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`star ${index < rating ? 'filled' : 'empty'}`}
        size={16}
        fill={index < rating ? '#FFD93D' : 'none'}
      />
    ))
  }

  return (
    <div className="app">
      {/* Sidebar */}
      <div className="sidebar">
        <div className="sidebar-header">
          <div className="logo">
            <img src="/assets/images/logo.jpg" alt="DateWeave" className="logo-circle" />
          </div>
        </div>

        <nav className="nav-menu">
          {[
            { id: 'profile', label: 'Profile', icon: User },
            { id: 'add', label: 'Add', icon: Plus },
            { id: 'calendar', label: 'Calendar', icon: Calendar },
            { id: 'room', label: 'Room', icon: Home },
            { id: 'settings', label: 'Settings', icon: Settings },
          ].map((item) => {
            const IconComponent = item.icon
            return (
              <div
                key={item.id}
                className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
                onClick={() => handleNavClick(item.id)}
              >
                <IconComponent size={20} />
                <span>{item.label}</span>
              </div>
            )
          })}
        </nav>
      </div>

      {/* Main Content */}
      <main className="main-content">
        {/* Header */}
        <header className="header">
          <h1>Profile</h1>
          <button className="logout-btn" onClick={handleLogout}>
            <LogOut size={20} />
            <span>Log Out</span>
          </button>
        </header>

        {/* Profile Section */}
        <section className="profile-section">
          <div className="profile-card">
            <div className="profile-header">
              <div className="profile-avatar">
                <img
                  src={profileData.user.profilePicture}
                  alt={profileData.user.name}
                  onError={(e) => {
                    e.target.src = 'https://via.placeholder.com/120x120?text=User'
                  }}
                />
                <div className="online-indicator"></div>
              </div>
              <div className="profile-info">
                <h2>{profileData.user.name}</h2>
                <div className="profile-phone">
                  <Phone size={16} />
                  {profileData.user.phone}
                </div>
                <div className="profile-email">
                  <User size={16} />
                  {profileData.user.email}
                </div>
              </div>
            </div>

            <div className="profile-stats">
              <div className="stat-item">
                <div className="stat-number">{profileData.user.stats.totalPlans}</div>
                <div className="stat-label">Total Plans</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">{profileData.user.stats.succeededPlans}</div>
                <div className="stat-label">Succeeded</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">{profileData.user.stats.fanCount}</div>
                <div className="stat-label">Fans</div>
              </div>
            </div>
          </div>
        </section>

        {/* Recommendations Section */}
        <section className="recommendations-section">
          <h2 className="section-title">
            <Heart size={24} />
            Recommendations for You
          </h2>
          <div className="recommendations-grid">
            {profileData.recommendations.map((recommendation) => (
              <div key={recommendation.id} className="recommendation-card">
                <div className="recommendation-header">
                  <h3 className="recommendation-title">{recommendation.title}</h3>
                  <div className="recommendation-rating">
                    <Star size={14} fill="#4CAF50" />
                    {recommendation.rating}
                  </div>
                </div>
                <p className="recommendation-description">{recommendation.description}</p>
                <span className="recommendation-category">{recommendation.category}</span>
              </div>
            ))}
          </div>
        </section>

        {/* History Section */}
        <section className="history-section">
          <h2 className="section-title">
            <Calendar size={24} />
            Your Dating History
          </h2>
          <div className="history-list">
            {profileData.history.map((historyItem) => (
              <div key={historyItem.id} className="history-item">
                <div className="history-content">
                  <div className="history-date">
                    {new Date(historyItem.date).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric'
                    })}
                  </div>
                  <div className="history-details">
                    <h4>{historyItem.title}</h4>
                    <p className="history-partner">with {historyItem.partner}</p>
                  </div>
                </div>
                <div className="history-rating">
                  {renderStars(historyItem.rating)}
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}

export default Profile